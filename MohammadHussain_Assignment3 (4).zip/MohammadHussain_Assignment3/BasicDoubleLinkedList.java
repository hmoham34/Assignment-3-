
import java.util.ArrayList;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class BasicDoubleLinkedList<T> implements Iterable<T> {
    private Node head;
    private Node tail;
    private int size;

    public BasicDoubleLinkedList() {
        head = null;
        tail = null;
        size = 0;
    }

    /**
     * Adds an element to the end of the list.
     * @param data - the data to add
     * @return this list with the new element added
     */
    public BasicDoubleLinkedList<T> addToEnd(T data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            newNode.prev = tail;
            tail = newNode;
        }
        size++;
        return this;
    }

    /**
     * Adds an element to the front of the list.
     * @param data - the data to add
     * @return this list with the new element added
     */
    public BasicDoubleLinkedList<T> addToFront(T data) {
        Node newNode = new Node(data);

        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            newNode.next = head;
            head.prev = newNode;
            head = newNode;
        }
        size++;
        return this;
    }

    /**
     * Returns the first element without removing it.
     * @return first element or null if list is empty
     */
    public T getFirst() {
        return isEmpty() ? null : head.data;
    }

    /**
     * Returns the last element without removing it.
     * @return last element or null if list is empty
     */
    public T getLast() {
        return isEmpty() ? null : tail.data;
    }

    /**
     * Returns the size of the list.
     * @return size of the list
     */
    public int size() {
        return size;
    }

    /**
     * Removes the first element from the list and returns it.
     * @return removed element or null if list is empty
     */
    public T retrieveFirstElement() {
        if (isEmpty()) return null;
        
        T data = head.data;
        if (size == 1) {
            head = null;
            tail = null;
        } else {
            head = head.next;
            head.prev = null;
        }
        size--;
        return data;
    }

    /**
     * Removes the last element from the list and returns it.
     * @return removed element or null if list is empty
     */
    public T retrieveLastElement() {
        if (isEmpty()) return null;
        
        T data = tail.data;
        if (size == 1) {
            head = null;
            tail = null;
        } else {
            tail = tail.prev;
            tail.next = null;
        }
        size--;
        return data;
    }

    /**
     * Removes the first occurrence of targetData in the list using the provided comparator.
     * @param targetData - the data to remove
     * @param comparator - comparator to match the data
     * @return this list with the target data removed if it was found
     */
    public BasicDoubleLinkedList<T> remove(T targetData, Comparator<T> comparator) {
        Node current = head;

        while (current != null) {
            if (comparator.compare(current.data, targetData) == 0) {
                if (current == head) {
                    retrieveFirstElement();
                } else if (current == tail) {
                    retrieveLastElement();
                } else {
                    current.prev.next = current.next;
                    current.next.prev = current.prev;
                    size--;
                }
                return this;
            }
            current = current.next;
        }
        return this;
    }

    /**
     * Converts the list into an ArrayList of its elements.
     * @return ArrayList containing all the elements in the list
     */
    public ArrayList<T> toArrayList() {
        ArrayList<T> result = new ArrayList<>();
        Node current = head;

        while (current != null) {
            result.add(current.data);
            current = current.next;
        }
        return result;
    }

    /**
     * Checks if the list is empty.
     * @return true if list is empty, false otherwise
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Provides an iterator over the list.
     * @return a ListIterator for the list
     */
    @Override
    public ListIterator<T> iterator() {
        return new NodeIterator();
    }

    private class Node {
        private Node prev;
        private Node next;
        private T data;

        public Node(T data) {
            this.data = data;
        }
    }

    private class NodeIterator implements ListIterator<T> {
        private Node current = head;
        private Node lastReturned = null;

        @Override
        public boolean hasNext() {
            return current != null;
        }

        @Override
        public T next() {
            if (!hasNext()) throw new NoSuchElementException();
            lastReturned = current;
            current = current.next;
            return lastReturned.data;
        }

        @Override
        public boolean hasPrevious() {
            return lastReturned != null && lastReturned.prev != null;
        }

        @Override
        public T previous() {
            if (!hasPrevious()) throw new NoSuchElementException();
            current = lastReturned;
            lastReturned = lastReturned.prev;
            return current.data;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int nextIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public int previousIndex() {
            throw new UnsupportedOperationException();
        }

        @Override
        public void set(T t) {
            throw new UnsupportedOperationException();
        }

        @Override
        public void add(T t) {
            throw new UnsupportedOperationException();
        }
    }
}


