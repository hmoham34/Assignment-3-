import java.util.Comparator;
import java.util.ListIterator;

/**
 * Implements a generic sorted double linked list using a provided Comparator. It extends
 * BasicDoubleLinkedList class.
 */
public class SortedDoubleLinkedList<T> extends BasicDoubleLinkedList<T> {

    private Comparator<T> comparator;

    /**
     * Creates an empty sorted list that uses the specified comparator for ordering.
     * 
     * @param comparator - Comparator to compare data elements
     */
    public SortedDoubleLinkedList(Comparator<T> comparator) {
        this.comparator = comparator;
    }

    /**
     * Inserts the specified element at the correct position in the sorted list.
     * 
     * @param data - the data to be added to the list
     * @return reference to the current object
     */
    public SortedDoubleLinkedList<T> add(T data) {
        Node newNode = new Node(data);

        // If the list is empty, insert as the only element
        if (isEmpty()) {
            head = newNode;
            tail = newNode;
        } else {
            Node current = head;

            // Check if the new data should be inserted at the beginning
            if (comparator.compare(data, head.data) <= 0) {
                newNode.next = head;
                head.prev = newNode;
                head = newNode;
            } else {
                // Traverse and find the correct position
                while (current != null && comparator.compare(data, current.data) > 0) {
                    current = current.next;
                }

                // If current is null, insert at the end
                if (current == null) {
                    tail.next = newNode;
                    newNode.prev = tail;
                    tail = newNode;
                } else {
                    // Insert between two nodes
                    newNode.prev = current.prev;
                    newNode.next = current;
                    current.prev.next = newNode;
                    current.prev = newNode;
                }
            }
        }
        size++;
        return this;
    }

    /**
     * Removes the specified element using the super class remove method.
     * 
     * @param data - the data element to be removed
     * @param comparator - the comparator to determine equality of data elements
     * @return reference to the current object
     */
    @Override
    public SortedDoubleLinkedList<T> remove(T data, Comparator<T> comparator) {
        super.remove(data, comparator);
        return this;
    }

    /**
     * Returns a ListIterator over the elements of the list starting from the head.
     * 
     * @return ListIterator for the list
     */
    @Override
    public ListIterator<T> iterator() {
        return super.iterator();
    }

    /**
     * Invalid operation for a sorted list. Adding to the end is not allowed.
     * 
     * @param data - the data element to be added
     * @throws UnsupportedOperationException when invoked
     */
    @Override
    public BasicDoubleLinkedList<T> addToEnd(T data) {
        throw new UnsupportedOperationException("Cannot add to end in a sorted list");
    }

    /**
     * Invalid operation for a sorted list. Adding to the front is not allowed.
     * 
     * @param data - the data element to be added
     * @throws UnsupportedOperationException when invoked
     */
    @Override
    public BasicDoubleLinkedList<T> addToFront(T data) {
        throw new UnsupportedOperationException("Cannot add to front in a sorted list");
    }
}
