import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import java.util.Comparator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class SortedDoubleLinkedList_STUDENT_Test {

    private SortedDoubleLinkedList<Album> sortedLinkedAlbum;
    private AlbumComparator comparator;

    // Sample albums for testing
    private Album album1 = new Album("A Perfect Circle", "Thirteenth Step", 2003);
    private Album album2 = new Album("Metallica", "And Justice for All", 1988);
    private Album album3 = new Album("Nirvana", "Bleach", 1989);
    private Album album4 = new Album("Deftones", "Adrenaline", 1995);
    private Album album5 = new Album("The Strokes", "Is This It", 2001);
    // Expected band order = album1, album4, album2, album3, album5

    @Before
    public void setUp() throws Exception {
        comparator = new AlbumComparator();
        sortedLinkedAlbum = new SortedDoubleLinkedList<>(comparator);
    }

    @After
    public void tearDown() throws Exception {
        comparator = null;
        sortedLinkedAlbum = null;
    }

    @Test
    public void testAddToEnd() {
        try {
            sortedLinkedAlbum.addToEnd(album5);
            assertTrue("Expected UnsupportedOperationException, but none was thrown.", false);
        } catch (UnsupportedOperationException e) {
            assertTrue("Successfully threw an UnsupportedOperationException.", true);
        } catch (Exception e) {
            assertTrue("Unexpected exception type.", false);
        }
    }

    @Test
    public void testAddToFront() {
        try {
            sortedLinkedAlbum.addToFront(album1);
            assertTrue("Expected UnsupportedOperationException, but none was thrown.", false);
        } catch (UnsupportedOperationException e) {
            assertTrue("Successfully threw an UnsupportedOperationException.", true);
        } catch (Exception e) {
            assertTrue("Unexpected exception type.", false);
        }
    }

    @Test
    public void testIteratorSuccessfulNext() {
        // Adding albums
        sortedLinkedAlbum.add(album1);
        sortedLinkedAlbum.add(album2);
        sortedLinkedAlbum.add(album3);
        sortedLinkedAlbum.add(album4);

        ListIterator<Album> iterator = sortedLinkedAlbum.iterator();
        assertEquals(true, iterator.hasNext());
        assertEquals(album1, iterator.next());
        assertEquals(album4, iterator.next());
        assertEquals(album2, iterator.next());
        assertEquals(true, iterator.hasNext());
    }

    @Test
    public void testIteratorSuccessfulPrevious() {
        // Adding albums
        sortedLinkedAlbum.add(album1);
        sortedLinkedAlbum.add(album2);
        sortedLinkedAlbum.add(album3);
        sortedLinkedAlbum.add(album4);

        ListIterator<Album> iterator = sortedLinkedAlbum.iterator();
        assertEquals(true, iterator.hasNext());
        assertEquals(album1, iterator.next());
        assertEquals(album4, iterator.next());
        assertEquals(album2, iterator.next());
        assertEquals(true, iterator.hasPrevious());
        assertEquals(album2, iterator.previous());
        assertEquals(album4, iterator.previous());
        assertEquals(album1, iterator.previous());
    }

    @Test
    public void testIteratorNoSuchElementException() {
        // Adding albums
        sortedLinkedAlbum.add(album5);
        sortedLinkedAlbum.add(album3);
        sortedLinkedAlbum.add(album2);
        sortedLinkedAlbum.add(album4);

        ListIterator<Album> iterator = sortedLinkedAlbum.iterator();
        assertEquals(true, iterator.hasNext());
        assertEquals(album4, iterator.next());
        assertEquals(album2, iterator.next());
        assertEquals(album3, iterator.next());
        assertEquals(album5, iterator.next());
        assertEquals(false, iterator.hasNext());

        try {
            iterator.next(); // Should throw exception
            assertTrue("Expected NoSuchElementException, but none was thrown.", false);
        } catch (NoSuchElementException e) {
            assertTrue("Successfully threw a NoSuchElementException.", true);
        } catch (Exception e) {
            assertTrue("Unexpected exception type.", false);
        }
    }

    @Test
    public void testIteratorUnsupportedOperationException() {
        // Adding albums
        sortedLinkedAlbum.add(album5);
        sortedLinkedAlbum.add(album3);
        sortedLinkedAlbum.add(album2);
        sortedLinkedAlbum.add(album4);

        ListIterator<Album> iterator = sortedLinkedAlbum.iterator();

        try {
            iterator.remove(); // Unsupported operation
            assertTrue("Expected UnsupportedOperationException, but none was thrown.", false);
        } catch (UnsupportedOperationException e) {
            assertTrue("Successfully threw an UnsupportedOperationException.", true);
        } catch (Exception e) {
            assertTrue("Unexpected exception type.", false);
        }
    }

    @Test
    public void testAddAlbum() {
        // Adding albums in different order and checking first/last
        sortedLinkedAlbum.add(album1);
        sortedLinkedAlbum.add(album2);
        sortedLinkedAlbum.add(album3);
        assertEquals(album1, sortedLinkedAlbum.getFirst());
        assertEquals(album3, sortedLinkedAlbum.getLast());
        sortedLinkedAlbum.add(album4);
        sortedLinkedAlbum.add(album5);
        assertEquals(album1, sortedLinkedAlbum.getFirst());
        assertEquals(album5, sortedLinkedAlbum.getLast());

        assertEquals(album5, sortedLinkedAlbum.retrieveLastElement());
        assertEquals(album3, sortedLinkedAlbum.getLast());
    }

    @Test
    public void testRemoveFirstAlbum() {
        // Adding albums and removing the first
        sortedLinkedAlbum.add(album3);
        sortedLinkedAlbum.add(album4);
        assertEquals(album4, sortedLinkedAlbum.getFirst());
        assertEquals(album3, sortedLinkedAlbum.getLast());
        sortedLinkedAlbum.add(album1);
        assertEquals(album1, sortedLinkedAlbum.getFirst());
        sortedLinkedAlbum.remove(album1, comparator);
        assertEquals(album4, sortedLinkedAlbum.getFirst());
    }

    @Test
    public void testRemoveEndAlbum() {
        // Adding albums and removing the last
        sortedLinkedAlbum.add(album2);
        sortedLinkedAlbum.add(album4);
        assertEquals(album4, sortedLinkedAlbum.getFirst());
        assertEquals(album2, sortedLinkedAlbum.getLast());
        sortedLinkedAlbum.add(album3);
        assertEquals(album3, sortedLinkedAlbum.getLast());
        sortedLinkedAlbum.remove(album3, comparator);
        assertEquals(album2, sortedLinkedAlbum.getLast());
    }

    @Test
    public void testRemoveMiddleAlbum() {
        // Adding albums and removing from the middle
        sortedLinkedAlbum.add(album2);
        sortedLinkedAlbum.add(album4);
        assertEquals(album4, sortedLinkedAlbum.getFirst());
        assertEquals(album2, sortedLinkedAlbum.getLast());
        sortedLinkedAlbum.add(album3);
        assertEquals(album4, sortedLinkedAlbum.getFirst());
        assertEquals(album3, sortedLinkedAlbum.getLast());
        assertEquals(3, sortedLinkedAlbum.getSize());
        sortedLinkedAlbum.remove(album2, comparator);
        assertEquals(album4, sortedLinkedAlbum.getFirst());
        assertEquals(album3, sortedLinkedAlbum.getLast());
        assertEquals(2, sortedLinkedAlbum.getSize());
    }

    // Custom comparator for albums, compares based on band names
    private class AlbumComparator implements Comparator<Album> {
        @Override
        public int compare(Album first, Album second) {
            return first.getBandName().compareTo(second.getBandName());
        }
    }

    // Album class used for testing
    private class Album {
        private String bandName;
        private String title;
        private int year;

        public Album(String bandName, String title, int year) {
            this.bandName = bandName;
            this.title = title;
            this.year = year;
        }

        public String getBandName() {
            return bandName;
        }

        public String getTitle() {
            return title;
        }

        public int getYear() {
            return year;
        }

        @Override
        public String toString() {
            return bandName + " - " + title + " (" + year + ")";
        }
    }
}
